<div class="add-user-mail">
    <span>Date: <?php echo e(date('d/m/Y h:i:s a',strtotime($user->created_at))); ?></span>
    <h1><?php echo e($user->name.','); ?></h1>
    <p>
        Your user account has been created for <a href="https://www.zamanmess.zamanscorp.com">zamanmess.zamanscorp.com</a>. Use this mail to login as a user. Your password is <b><?php echo e($password); ?></b>.
    </p>
    <span>Curtesy</span>
    <h2>Zaman Mess</h2>
</div>
<?php /**PATH D:\My Codes\MessManagementV2\resources\views/defult/add-user-mail.blade.php ENDPATH**/ ?>