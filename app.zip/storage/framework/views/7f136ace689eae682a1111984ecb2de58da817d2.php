<div class="container-fluid">
        <h4>Settings</h4>

        <div class="colors">
            <h5>Choose your color settings</h5>
            <div class="sections">
                <div class="elements zero">
                    <label class="form-label" for="secondary_text_background_color">Select background color</label>
                    <select name="secondary_text_background_color" id="primary_background_color" class="form-select" onchange="changePrimaryBackground()">
                        <option value="">Select a background color</option>
                        <option <?php echo e(strcmp('black', getSettings('primary')) == 0 ? 'selected' : ''); ?> value="black">Black</option>
                        <option <?php echo e(strcmp('blue', getSettings('primary')) == 0 ? 'selected' : ''); ?> value="blue">Blue</option>
                        <option <?php echo e(strcmp('brown', getSettings('primary')) == 0 ? 'selected' : ''); ?> value="brown">Brown</option>
                        <option <?php echo e(strcmp('cyan', getSettings('primary')) == 0 ? 'selected' : ''); ?> value="cyan">Cyan</option>
                        <option <?php echo e(strcmp('gold', getSettings('primary')) == 0 ? 'selected' : ''); ?> value="gold">Gold</option>
                        <option <?php echo e(strcmp('gray', getSettings('primary')) == 0 ? 'selected' : ''); ?> value="gray">Gray</option>
                        <option <?php echo e(strcmp('green', getSettings('primary')) == 0 ? 'selected' : ''); ?> value="green">Green</option>
                        <option <?php echo e(strcmp('indigo', getSettings('primary')) == 0 ? 'selected' : ''); ?> value="indigo">Indigo</option>
                        <option <?php echo e(strcmp('lime', getSettings('primary')) == 0 ? 'selected' : ''); ?> value="lime">Lime</option>
                        <option <?php echo e(strcmp('magenta', getSettings('primary')) == 0 ? 'selected' : ''); ?> value="magenta">Magenta</option>
                        <option <?php echo e(strcmp('maroon', getSettings('primary')) == 0 ? 'selected' : ''); ?> value="maroon">Maroon</option>
                        <option <?php echo e(strcmp('orange', getSettings('primary')) == 0 ? 'selected' : ''); ?> value="orange">Orange</option>
                        <option <?php echo e(strcmp('pink', getSettings('primary')) == 0 ? 'selected' : ''); ?> value="pink">Pink</option>
                        <option <?php echo e(strcmp('purple', getSettings('primary')) == 0 ? 'selected' : ''); ?> value="purple">Purple</option>
                        <option <?php echo e(strcmp('red', getSettings('primary')) == 0 ? 'selected' : ''); ?> value="red">Red</option>
                        <option <?php echo e(strcmp('silver', getSettings('primary')) == 0 ? 'selected' : ''); ?> value="silver">Silver</option>
                        <option <?php echo e(strcmp('snow', getSettings('primary')) == 0 ? 'selected' : ''); ?> value="snow">Snow</option>
                        <option <?php echo e(strcmp('tomato', getSettings('primary')) == 0 ? 'selected' : ''); ?> value="tomato">Tomato</option>
                        <option <?php echo e(strcmp('violet', getSettings('primary')) == 0 ? 'selected' : ''); ?> value="violet">Violet</option>
                        <option <?php echo e(strcmp('white', getSettings('primary')) == 0 ? 'selected' : ''); ?> value="white">White</option>
                        <option <?php echo e(strcmp('yellow', getSettings('primary')) == 0 ? 'selected' : ''); ?> value="yellow">Yellow</option>
                        <option <?php echo e(strcmp('custom', getSettings('primary')) == 0 ? 'selected' : ''); ?> value="custom">Custom</option>
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                    </select>

                    <label class="form-label" for="primary_text_color">Select text color</label>
                    <select name="primary_text_color" id="primary_text_color" class="form-select"
                        onchange="changePrimaryText()">
                        <option value="">Select a text color</option>
                        <option <?php echo e(strcmp('black', getSettings('primary_text')) == 0 ? 'selected' : ''); ?> value="black">Black</option>
                        <option <?php echo e(strcmp('blue', getSettings('primary_text')) == 0 ? 'selected' : ''); ?> value="blue">Blue</option>
                        <option <?php echo e(strcmp('brown', getSettings('primary_text')) == 0 ? 'selected' : ''); ?> value="brown">Brown</option>
                        <option <?php echo e(strcmp('cyan', getSettings('primary_text')) == 0 ? 'selected' : ''); ?> value="cyan">Cyan</option>
                        <option <?php echo e(strcmp('gold', getSettings('primary_text')) == 0 ? 'selected' : ''); ?> value="gold">Gold</option>
                        <option <?php echo e(strcmp('gray', getSettings('primary_text')) == 0 ? 'selected' : ''); ?> value="gray">Gray</option>
                        <option <?php echo e(strcmp('green', getSettings('primary_text')) == 0 ? 'selected' : ''); ?> value="green">Green</option>
                        <option <?php echo e(strcmp('indigo', getSettings('primary_text')) == 0 ? 'selected' : ''); ?> value="indigo">Indigo</option>
                        <option <?php echo e(strcmp('lime', getSettings('primary_text')) == 0 ? 'selected' : ''); ?> value="lime">Lime</option>
                        <option <?php echo e(strcmp('magenta', getSettings('primary_text')) == 0 ? 'selected' : ''); ?> value="magenta">Magenta</option>
                        <option <?php echo e(strcmp('maroon', getSettings('primary_text')) == 0 ? 'selected' : ''); ?> value="maroon">Maroon</option>
                        <option <?php echo e(strcmp('orange', getSettings('primary_text')) == 0 ? 'selected' : ''); ?> value="orange">Orange</option>
                        <option <?php echo e(strcmp('pink', getSettings('primary_text')) == 0 ? 'selected' : ''); ?> value="pink">Pink</option>
                        <option <?php echo e(strcmp('purple', getSettings('primary_text')) == 0 ? 'selected' : ''); ?> value="purple">Purple</option>
                        <option <?php echo e(strcmp('red', getSettings('primary_text')) == 0 ? 'selected' : ''); ?> value="red">Red</option>
                        <option <?php echo e(strcmp('silver', getSettings('primary_text')) == 0 ? 'selected' : ''); ?> value="silver">Silver</option>
                        <option <?php echo e(strcmp('snow', getSettings('primary_text')) == 0 ? 'selected' : ''); ?> value="snow">Snow</option>
                        <option <?php echo e(strcmp('tomato', getSettings('primary_text')) == 0 ? 'selected' : ''); ?> value="tomato">Tomato</option>
                        <option <?php echo e(strcmp('violet', getSettings('primary_text')) == 0 ? 'selected' : ''); ?> value="violet">Violet</option>
                        <option <?php echo e(strcmp('white', getSettings('primary_text')) == 0 ? 'selected' : ''); ?> value="white">White</option>
                        <option <?php echo e(strcmp('yellow', getSettings('primary_text')) == 0 ? 'selected' : ''); ?> value="yellow">Yellow</option>
                        <option <?php echo e(strcmp('custom', getSettings('primary')) == 0 ? 'selected' : ''); ?> value="custom">Custom</option>
                    </select>
                </div>
                <div class="elements first">
                    <label for="primary" class="form-label">Primary Color</label>

                    <div class="rgb">
                        <div class="color">
                            R
                            <input type="range" min="0", max="255" id="primary_color_r" class="color-picker r" oninput="reloadPrimarySettingsColor()" value="<?php echo e($primary_color_r); ?>" disabled>
                        </div>
                        <div class="color">
                            G
                            <input type="range" min="0", max="255" id="primary_color_g" class="color-picker g" oninput="reloadPrimarySettingsColor()" value="<?php echo e($primary_color_g); ?>" disabled>
                        </div>
                        <div class="color">
                            B
                            <input type="range" min="0", max="255" id="primary_color_b" class="color-picker b" oninput="reloadPrimarySettingsColor()" value="<?php echo e($primary_color_b); ?>" disabled>
                        </div>
                    </div>
                </div>

                <div class="elements second">
                    <label for="primary_text" class="form-label">Primary Text Color</label>

                    <div class="rgb">
                        <div class="color">
                            R
                            <input type="range" min="0", max="255" id="primary_text_r" class="color-picker r" oninput="reloadPrimarySettingsColor()" value="<?php echo e($primary_text_r); ?>" disabled>
                        </div>
                        <div class="color">
                            G
                            <input type="range" min="0", max="255" id="primary_text_g" class="color-picker g" oninput="reloadPrimarySettingsColor()" value="<?php echo e($primary_text_g); ?>" disabled>
                        </div>
                        <div class="color">
                            B
                            <input type="range" min="0", max="255" id="primary_text_b" class="color-picker b" oninput="reloadPrimarySettingsColor()" value="<?php echo e($primary_text_b); ?>" disabled>
                        </div>
                    </div>
                </div>

                <div class="elements last" id="primary_div">
                    <span id="primary_background_rgb_value"><?php echo e('Background-color: ' . getSettings('primary')); ?></span>
                    <span id="primary_text_rgb_value"><?php echo e('Text-color: ' . getSettings('primary_text')); ?></span>
                    <p id="primary_p">Lorem ipsum dolor sit amet consectetur adipisicing elit. Amet, reiciendis!</p>
                </div>
            </div>

            <div class="sections">
                <div class="elements zero">
                    <label class="form-label" for="secondary_background_color">Select background color</label>
                    <select name="secondary_background_color" id="secondary_background_color" class="form-select"
                        onchange="changeSecondaryBackground()">
                        <option value="">Select a background color</option>
                        <option <?php echo e(strcmp('black', getSettings('secondary')) == 0 ? 'selected' : ''); ?> value="black">Black</option>
                        <option <?php echo e(strcmp('blue', getSettings('secondary')) == 0 ? 'selected' : ''); ?> value="blue">Blue</option>
                        <option <?php echo e(strcmp('brown', getSettings('secondary')) == 0 ? 'selected' : ''); ?> value="brown">Brown</option>
                        <option <?php echo e(strcmp('cyan', getSettings('secondary')) == 0 ? 'selected' : ''); ?> value="cyan">Cyan</option>
                        <option <?php echo e(strcmp('gold', getSettings('secondary')) == 0 ? 'selected' : ''); ?> value="gold">Gold</option>
                        <option <?php echo e(strcmp('gray', getSettings('secondary')) == 0 ? 'selected' : ''); ?> value="gray">Gray</option>
                        <option <?php echo e(strcmp('green', getSettings('secondary')) == 0 ? 'selected' : ''); ?> value="green">Green</option>
                        <option <?php echo e(strcmp('indigo', getSettings('secondary')) == 0 ? 'selected' : ''); ?> value="indigo">Indigo</option>
                        <option <?php echo e(strcmp('lime', getSettings('secondary')) == 0 ? 'selected' : ''); ?> value="lime">Lime</option>
                        <option <?php echo e(strcmp('magenta', getSettings('secondary')) == 0 ? 'selected' : ''); ?> value="magenta">Magenta</option>
                        <option <?php echo e(strcmp('maroon', getSettings('secondary')) == 0 ? 'selected' : ''); ?> value="maroon">Maroon</option>
                        <option <?php echo e(strcmp('orange', getSettings('secondary')) == 0 ? 'selected' : ''); ?> value="orange">Orange</option>
                        <option <?php echo e(strcmp('pink', getSettings('secondary')) == 0 ? 'selected' : ''); ?> value="pink">Pink</option>
                        <option <?php echo e(strcmp('purple', getSettings('secondary')) == 0 ? 'selected' : ''); ?> value="purple">Purple</option>
                        <option <?php echo e(strcmp('red', getSettings('secondary')) == 0 ? 'selected' : ''); ?> value="red">Red</option>
                        <option <?php echo e(strcmp('silver', getSettings('secondary')) == 0 ? 'selected' : ''); ?> value="silver">Silver</option>
                        <option <?php echo e(strcmp('snow', getSettings('secondary')) == 0 ? 'selected' : ''); ?> value="snow">Snow</option>
                        <option <?php echo e(strcmp('tomato', getSettings('secondary')) == 0 ? 'selected' : ''); ?> value="tomato">Tomato</option>
                        <option <?php echo e(strcmp('violet', getSettings('secondary')) == 0 ? 'selected' : ''); ?> value="violet">Violet</option>
                        <option <?php echo e(strcmp('white', getSettings('secondary')) == 0 ? 'selected' : ''); ?> value="white">White</option>
                        <option <?php echo e(strcmp('yellow', getSettings('secondary')) == 0 ? 'selected' : ''); ?> value="yellow">Yellow</option>
                        <option <?php echo e(strcmp('custom', getSettings('secondary')) == 0 ? 'selected' : ''); ?> value="custom">Custom</option>
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                    </select>

                    <label class="form-label" for="secondary_text_color">Select text color</label>
                    <select name="secondary_text_color" id="secondary_text_color" class="form-select" onchange="changeSecondaryText()">
                        <option value="">Select a background color</option>
                        <option <?php echo e(strcmp('black', getSettings('secondary_text')) == 0 ? 'selected' : ''); ?> value="black">Black</option>
                        <option <?php echo e(strcmp('blue', getSettings('secondary_text')) == 0 ? 'selected' : ''); ?> value="blue">Blue</option>
                        <option <?php echo e(strcmp('brown', getSettings('secondary_text')) == 0 ? 'selected' : ''); ?> value="brown">Brown</option>
                        <option <?php echo e(strcmp('cyan', getSettings('secondary_text')) == 0 ? 'selected' : ''); ?> value="cyan">Cyan</option>
                        <option <?php echo e(strcmp('gold', getSettings('secondary_text')) == 0 ? 'selected' : ''); ?> value="gold">Gold</option>
                        <option <?php echo e(strcmp('gray', getSettings('secondary_text')) == 0 ? 'selected' : ''); ?> value="gray">Gray</option>
                        <option <?php echo e(strcmp('green', getSettings('secondary_text')) == 0 ? 'selected' : ''); ?> value="green">Green</option>
                        <option <?php echo e(strcmp('indigo', getSettings('secondary_text')) == 0 ? 'selected' : ''); ?> value="indigo">Indigo</option>
                        <option <?php echo e(strcmp('lime', getSettings('secondary_text')) == 0 ? 'selected' : ''); ?> value="lime">Lime</option>
                        <option <?php echo e(strcmp('magenta', getSettings('secondary_text')) == 0 ? 'selected' : ''); ?> value="magenta">Magenta</option>
                        <option <?php echo e(strcmp('maroon', getSettings('secondary_text')) == 0 ? 'selected' : ''); ?> value="maroon">Maroon</option>
                        <option <?php echo e(strcmp('orange', getSettings('secondary_text')) == 0 ? 'selected' : ''); ?> value="orange">Orange</option>
                        <option <?php echo e(strcmp('pink', getSettings('secondary_text')) == 0 ? 'selected' : ''); ?> value="pink">Pink</option>
                        <option <?php echo e(strcmp('purple', getSettings('secondary_text')) == 0 ? 'selected' : ''); ?> value="purple">Purple</option>
                        <option <?php echo e(strcmp('red', getSettings('secondary_text')) == 0 ? 'selected' : ''); ?> value="red">Red</option>
                        <option <?php echo e(strcmp('silver', getSettings('secondary_text')) == 0 ? 'selected' : ''); ?> value="silver">Silver</option>
                        <option <?php echo e(strcmp('snow', getSettings('secondary_text')) == 0 ? 'selected' : ''); ?> value="snow">Snow</option>
                        <option <?php echo e(strcmp('tomato', getSettings('secondary_text')) == 0 ? 'selected' : ''); ?> value="tomato">Tomato</option>
                        <option <?php echo e(strcmp('violet', getSettings('secondary_text')) == 0 ? 'selected' : ''); ?> value="violet">Violet</option>
                        <option <?php echo e(strcmp('white', getSettings('secondary_text')) == 0 ? 'selected' : ''); ?> value="white">White</option>
                        <option <?php echo e(strcmp('yellow', getSettings('secondary_text')) == 0 ? 'selected' : ''); ?> value="yellow">Yellow</option>
                        <option <?php echo e(strcmp('custom', getSettings('secondary_text')) == 0 ? 'selected' : ''); ?> value="custom">Custom</option>
                    </select>
                </div>
                <div class="elements first">
                    <label for="secondary" class="form-label">Secondary Color</label>

                    <div class="rgb">
                        <div class="color">
                            R
                            <input type="range" min="0", max="255" id="secondary_color_r" class="color-picker r" oninput="reloadSecondarySettingsColor()" value="<?php echo e($secondary_color_r); ?>" disabled>
                        </div>
                        <div class="color">
                            G
                            <input type="range" min="0", max="255" id="secondary_color_g" class="color-picker g" oninput="reloadSecondarySettingsColor()" value="<?php echo e($secondary_color_g); ?>" disabled>
                        </div>
                        <div class="color">
                            B
                            <input type="range" min="0", max="255" id="secondary_color_b" class="color-picker b" oninput="reloadSecondarySettingsColor()" value="<?php echo e($secondary_color_b); ?>" disabled>
                        </div>
                    </div>
                </div>

                <div class="elements second">
                    <label for="secondary_text" class="form-label">Secondary Text Color</label>

                    <div class="rgb">
                        <div class="color">
                            R
                            <input type="range" min="0", max="255" id="secondary_text_r" class="color-picker r" oninput="reloadSecondarySettingsColor()" value="<?php echo e($secondary_text_r); ?>" disabled>
                        </div>
                        <div class="color">
                            G
                            <input type="range" min="0", max="255" id="secondary_text_g" class="color-picker g" oninput="reloadSecondarySettingsColor()" value="<?php echo e($secondary_text_g); ?>" disabled>
                        </div>
                        <div class="color">
                            B
                            <input type="range" min="0", max="255" id="secondary_text_b" class="color-picker b" oninput="reloadSecondarySettingsColor()" value="<?php echo e($secondary_text_b); ?>" disabled>
                        </div>
                    </div>
                </div>

                <div class="elements last" id="secondary_div">
                    <span id="secondary_background_rgb_value"><?php echo e('Background-color: ' . getSettings('secondary')); ?></span>
                    <span id="secondary_text_rgb_value"><?php echo e('Text-color: ' . getSettings('secondary_text')); ?></span>
                    <p id="secondary_p">Lorem ipsum dolor sit amet consectetur adipisicing elit. Amet, reiciendis!</p>
                </div>
            </div>

            <div class="sections">
                <div class="elements zero">
                    <label class="form-label" for="third_background_color">Select background color</label>
                    <select name="third_background_color" id="third_background_color" class="form-select" onchange="changeThirdBackground()">
                        <option value="">Select a background color</option>
                        <option <?php echo e(strcmp('black', getSettings('third')) == 0 ? 'selected' : ''); ?> value="black">Black</option>
                        <option <?php echo e(strcmp('blue', getSettings('third')) == 0 ? 'selected' : ''); ?> value="blue">Blue</option>
                        <option <?php echo e(strcmp('brown', getSettings('third')) == 0 ? 'selected' : ''); ?> value="brown">Brown</option>
                        <option <?php echo e(strcmp('cyan', getSettings('third')) == 0 ? 'selected' : ''); ?> value="cyan">Cyan</option>
                        <option <?php echo e(strcmp('gold', getSettings('third')) == 0 ? 'selected' : ''); ?> value="gold">Gold</option>
                        <option <?php echo e(strcmp('gray', getSettings('third')) == 0 ? 'selected' : ''); ?> value="gray">Gray</option>
                        <option <?php echo e(strcmp('green', getSettings('third')) == 0 ? 'selected' : ''); ?> value="green">Green</option>
                        <option <?php echo e(strcmp('indigo', getSettings('third')) == 0 ? 'selected' : ''); ?> value="indigo">Indigo</option>
                        <option <?php echo e(strcmp('lime', getSettings('third')) == 0 ? 'selected' : ''); ?> value="lime">Lime</option>
                        <option <?php echo e(strcmp('magenta', getSettings('third')) == 0 ? 'selected' : ''); ?> value="magenta">Magenta</option>
                        <option <?php echo e(strcmp('maroon', getSettings('third')) == 0 ? 'selected' : ''); ?> value="maroon">Maroon</option>
                        <option <?php echo e(strcmp('orange', getSettings('third')) == 0 ? 'selected' : ''); ?> value="orange">Orange</option>
                        <option <?php echo e(strcmp('pink', getSettings('third')) == 0 ? 'selected' : ''); ?> value="pink">Pink</option>
                        <option <?php echo e(strcmp('purple', getSettings('third')) == 0 ? 'selected' : ''); ?> value="purple">Purple</option>
                        <option <?php echo e(strcmp('red', getSettings('third')) == 0 ? 'selected' : ''); ?> value="red">Red</option>
                        <option <?php echo e(strcmp('silver', getSettings('third')) == 0 ? 'selected' : ''); ?> value="silver">Silver</option>
                        <option <?php echo e(strcmp('snow', getSettings('third')) == 0 ? 'selected' : ''); ?> value="snow">Snow</option>
                        <option <?php echo e(strcmp('tomato', getSettings('third')) == 0 ? 'selected' : ''); ?> value="tomato">Tomato</option>
                        <option <?php echo e(strcmp('violet', getSettings('third')) == 0 ? 'selected' : ''); ?> value="violet">Violet</option>
                        <option <?php echo e(strcmp('white', getSettings('third')) == 0 ? 'selected' : ''); ?> value="white">White</option>
                        <option <?php echo e(strcmp('yellow', getSettings('third')) == 0 ? 'selected' : ''); ?> value="yellow">Yellow</option>
                        <option <?php echo e(strcmp('custom', getSettings('third')) == 0 ? 'selected' : ''); ?> value="custom">Custom</option>
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                    </select>

                    <label class="form-label" for="third_text_color">Select text color</label>
                    <select name="third_text_color" id="third_text_color" class="form-select" onchange="changeThirdText()">
                        <option value="">Select a background color</option>
                        <option <?php echo e(strcmp('black', getSettings('third_text')) == 0 ? 'selected' : ''); ?> value="black">Black</option>
                        <option <?php echo e(strcmp('blue', getSettings('third_text')) == 0 ? 'selected' : ''); ?> value="blue">Blue</option>
                        <option <?php echo e(strcmp('brown', getSettings('third_text')) == 0 ? 'selected' : ''); ?> value="brown">Brown</option>
                        <option <?php echo e(strcmp('cyan', getSettings('third_text')) == 0 ? 'selected' : ''); ?> value="cyan">Cyan</option>
                        <option <?php echo e(strcmp('gold', getSettings('third_text')) == 0 ? 'selected' : ''); ?> value="gold">Gold</option>
                        <option <?php echo e(strcmp('gray', getSettings('third_text')) == 0 ? 'selected' : ''); ?> value="gray">Gray</option>
                        <option <?php echo e(strcmp('green', getSettings('third_text')) == 0 ? 'selected' : ''); ?> value="green">Green</option>
                        <option <?php echo e(strcmp('indigo', getSettings('third_text')) == 0 ? 'selected' : ''); ?> value="indigo">Indigo</option>
                        <option <?php echo e(strcmp('lime', getSettings('third_text')) == 0 ? 'selected' : ''); ?> value="lime">Lime</option>
                        <option <?php echo e(strcmp('magenta', getSettings('third_text')) == 0 ? 'selected' : ''); ?> value="magenta">Magenta</option>
                        <option <?php echo e(strcmp('maroon', getSettings('third_text')) == 0 ? 'selected' : ''); ?> value="maroon">Maroon</option>
                        <option <?php echo e(strcmp('orange', getSettings('third_text')) == 0 ? 'selected' : ''); ?> value="orange">Orange</option>
                        <option <?php echo e(strcmp('pink', getSettings('third_text')) == 0 ? 'selected' : ''); ?> value="pink">Pink</option>
                        <option <?php echo e(strcmp('purple', getSettings('third_text')) == 0 ? 'selected' : ''); ?> value="purple">Purple</option>
                        <option <?php echo e(strcmp('red', getSettings('third_text')) == 0 ? 'selected' : ''); ?> value="red">Red</option>
                        <option <?php echo e(strcmp('silver', getSettings('third_text')) == 0 ? 'selected' : ''); ?> value="silver">Silver</option>
                        <option <?php echo e(strcmp('snow', getSettings('third_text')) == 0 ? 'selected' : ''); ?> value="snow">Snow</option>
                        <option <?php echo e(strcmp('tomato', getSettings('third_text')) == 0 ? 'selected' : ''); ?> value="tomato">Tomato</option>
                        <option <?php echo e(strcmp('violet', getSettings('third_text')) == 0 ? 'selected' : ''); ?> value="violet">Violet</option>
                        <option <?php echo e(strcmp('white', getSettings('third_text')) == 0 ? 'selected' : ''); ?> value="white">White</option>
                        <option <?php echo e(strcmp('yellow', getSettings('third_text')) == 0 ? 'selected' : ''); ?> value="yellow">Yellow</option>
                        <option <?php echo e(strcmp('custom', getSettings('third_text')) == 0 ? 'selected' : ''); ?> value="custom">Custom</option>
                    </select>
                </div>
                <div class="elements first">
                    <label for="third" class="form-label">Third Color</label>

                    <div class="rgb">
                        <div class="color">
                            R
                            <input type="range" min="0", max="255" id="third_color_r" class="color-picker r" oninput="reloadThirdSettingsColor()" value="<?php echo e($third_color_r); ?>" disabled>
                        </div>
                        <div class="color">
                            G
                            <input type="range" min="0", max="255" id="third_color_g" class="color-picker g" oninput="reloadThirdSettingsColor()" value="<?php echo e($third_color_g); ?>" disabled>
                        </div>
                        <div class="color">
                            B
                            <input type="range" min="0", max="255" id="third_color_b" class="color-picker b" oninput="reloadThirdSettingsColor()" value="<?php echo e($third_color_b); ?>" disabled>
                        </div>
                    </div>
                </div>

                <div class="elements second">
                    <label for="third_text" class="form-label">Third Text Color</label>

                    <div class="rgb">
                        <div class="color">
                            R
                            <input type="range" min="0", max="255" id="third_text_r" class="color-picker r" oninput="reloadThirdSettingsColor()" value="<?php echo e($third_text_r); ?>" disabled>
                        </div>
                        <div class="color">
                            G
                            <input type="range" min="0", max="255" id="third_text_g" class="color-picker g" oninput="reloadThirdSettingsColor()" value="<?php echo e($third_text_g); ?>" disabled>
                        </div>
                        <div class="color">
                            B
                            <input type="range" min="0", max="255" id="third_text_b" class="color-picker b" oninput="reloadThirdSettingsColor()" value="<?php echo e($third_text_b); ?>" disabled>
                        </div>
                    </div>
                </div>

                <div class="elements last" id="third_div">
                    <span id="third_background_rgb_value"><?php echo e('Background-color: ' . getSettings('third')); ?></span>
                    <span id="third_text_rgb_value"><?php echo e('Text-color: ' . getSettings('third_text')); ?></span>
                    <p id="third_p">Lorem ipsum dolor sit amet consectetur adipisicing elit. Amet, reiciendis!</p>
                </div>
            </div>
        </div>


        <div class="contacts">
            <h5>Enter contact information</h5>

            <div class="input-container">

                <div class="col-1">
                    <label for="company_name" class="form-label">Company Name</label>
                    <input type="text" name="company_name" id="company_name" placeholder="enter your company name" value="<?php echo e(getSettings('company_name')); ?>" class="form-control">

                    <label for="address">Address</label>
                    <textarea name="address" id="address" class="form-control"><?php echo e(getSettings('address')); ?></textarea>

                    <label for="phone" class="form-label">Company Phone</label>
                    <input type="text" name="phone" id="phone" placeholder="enter your company phone" value="<?php echo e(getSettings('phone')); ?>" class="form-control">
                </div>

                <div class="col-2">
                    <label for="email" class="form-label">Company Email</label>
                    <input type="text" name="email" id="email" placeholder="enter your company email" value="<?php echo e(getSettings('email')); ?>" class="form-control">
                    <label for="facebook" class="form-label">Company Facebook</label>
                    <input type="text" name="facebook" id="facebook" placeholder="enter your company facebook profile" value="<?php echo e(getSettings('facebook')); ?>" class="form-control">

                    <label for="instagram" class="form-label">Company Instagram</label>
                    <input type="text" name="instagram" id="instagram" placeholder="enter your company instagram profile" value="<?php echo e(getSettings('instagram')); ?>" class="form-control">

                    <label for="twitter" class="form-label">Company Twitter</label>
                    <input type="text" name="twitter" id="twitter" laceholder="enter your company twitter" value="<?php echo e(getSettings('twitter')); ?>" class="form-control">
                </div>
            </div>



            

            <div class="btn-container">
                <button class="btn btn-primary" id="save-settings">Save</button>
                <a href="<?php echo e(route('home')); ?>" class="btn btn-secondary">Cancel</a>
            </div>
        </div>
    </div>
<?php /**PATH D:\My Codes\MessManagementV2\resources\views/defult/setting.blade.php ENDPATH**/ ?>