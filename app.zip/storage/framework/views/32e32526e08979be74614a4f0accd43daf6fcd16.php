<table class="table table-dark table-striped table-hover table-bordered">
    <thead>
        <tr>
            <th>No</th>
            <th>Status</th>
            <th>Heading</th>
            <th>Created By</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $notices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr class="clickable" data-href="<?php echo e(route('notices.show',$notice->id)); ?>">
            <td class="center"><?php echo e($loop->iteration); ?></td>
            <td class="center"><?php echo e(ucwords($notice->status)); ?></td>
            <td class="center"><?php echo e(Str::limit($notice->heading,50,'...')); ?></td>
            <td class="center"><?php echo e($notice->user->name); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php echo e($notices->links()); ?>

<?php /**PATH D:\My Codes\MessManagementV2\resources\views/notice/search.blade.php ENDPATH**/ ?>