<table class="table table-dark table-striped table-hover table-bordered">
    <thead>
        <tr>
            <th>No</th>
            <th>Name</th>
            <th>Status</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $months; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr class="clickable" data-href="<?php echo e(route('months.show',$month->id)); ?>">
            <td class="center"><?php echo e($loop->iteration); ?></td>
            <td class="center"><?php echo e($month->name.' ['.date('F',strtotime($month->name)).']'); ?></td>
            <td class="center"><?php echo e(ucwords($month->status)); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php echo e($months->links()); ?>

<?php /**PATH D:\My Codes\MessManagementV2\resources\views/month/search.blade.php ENDPATH**/ ?>