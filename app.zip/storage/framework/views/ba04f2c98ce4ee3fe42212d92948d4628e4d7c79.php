<table class="table table-dark table-striped table-hover table-bordered">
    <thead>
        <tr>
            <th>No</th>
            <th>Name</th>
            <th>Floor</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Status</th>
            <th>Current Balance</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr class="clickable" data-href="<?php echo e(route('members.show',$member->id)); ?>">
            <td class="center"><?php echo e($loop->iteration); ?></td>
            <td class="left"><?php echo e($member->name); ?></td>
            <td class="center"><?php echo e($member->floor); ?></td>
            <td class="center"><?php echo e($member->email); ?></td>
            <td class="center"><?php echo e($member->phone); ?></td>
            <td class="center"><?php echo e(ucwords($member->status)); ?></td>
            <td class="right"><?php echo e(number_format($member->current_balance)); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php echo e($members->links()); ?>

<?php /**PATH D:\My Codes\MessManagementV2\resources\views/member/search.blade.php ENDPATH**/ ?>