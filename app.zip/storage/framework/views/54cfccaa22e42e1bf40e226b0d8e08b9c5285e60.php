
<h3 id="home_notice_view_header"><?php echo e($notice->heading); ?></h3>
<p id="home_notice_view_body" class="body"><?php echo e($notice->body); ?></p>
<p id="home_notice_view_footer" class="footer">
    <span id="home_notice_view_admin" class="admin"><?php echo e($notice->user->name); ?></span>
    <span id="home_notice_view_time" class="date"><?php echo e(date('D, M-d, Y',strtotime($notice->created_at))); ?></span>
</p>
<span id="home_notice_view_close" class="close">X</span>

<?php /**PATH D:\My Codes\MessManagementV2\resources\views/defult/home-notice.blade.php ENDPATH**/ ?>