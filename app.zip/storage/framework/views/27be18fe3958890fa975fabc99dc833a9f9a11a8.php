<div class="payment-mail">
    <span>Date: <?php echo e(date('d/m/Y h:i:s a',strtotime($payment->created_at))); ?></span>
    <h1><?php echo e($payment->memberMonth->member->name.','); ?></h1>
    <p>
        Your payment of <b><?php echo e($payment->amount.' Tk'); ?></b> has been confirmed. Your current balance is <b><?php echo e($payment->memberMonth->due.' Tk'); ?></b>. Please contact <i><?php echo e($payment->user->name.' ['.$payment->user->phone.']'); ?></i> for any query.
    </p>
    <h2>Yours sincerely, <b><?php echo e($payment->user->name); ?></b></h2>
</div>
<?php /**PATH D:\My Codes\MessManagementV2\resources\views/defult/payment-mail.blade.php ENDPATH**/ ?>