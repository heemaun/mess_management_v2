<div id="member_show" class="member-show">
    <div class="top">
        <h2>Member Details</h2>
        <div class="btn-container">
            <a href="<?php echo e(route('payments.create')); ?>" data-id="<?php echo e($member->id); ?>" data-floor="<?php echo e($member->floor); ?>" id="member_show_add_payment" class="btn btn-primary">Add Payment</a>
            <a href="<?php echo e(route('members.edit',$member->id)); ?>" id="member_show_edit" class="btn btn-success">Edit</a>
            <button type="button" id="member_show_delete" class="btn btn-danger">Delete</button>
            <a href="<?php echo e(route('members.index')); ?>" id="member_show_back" class="btn btn-secondary">Back</a>
        </div>
    </div>

    <div class="image-viewer">
        <img src="<?php echo e(asset('images/default_member_picture_male.png')); ?>" alt="">
    </div>

    <div class="details-container">
        <div class="info-container">
            <h3>Member Information</h3>
            <label for="">Name:<span><?php echo e($member->name); ?></span></label>
            <label for="">Status:<span><?php echo e(ucwords($member->status)); ?></span></label>
            <label for="">Floor:<span><?php echo e($member->floor); ?></span></label>
            <label for="">Email:<span><?php echo e((!empty($member->email)) ? $member->email : 'N/A'); ?></span></label>
            <label for="">Phone:<span><?php echo e($member->phone); ?></span></label>
            <label for="">Initial Balance:<span><?php echo e($member->initial_balance); ?></span></label>
            <label for="">Current Balance:<span><?php echo e($member->current_balance); ?></span></label>
            <label for="">Joining Date:<span><?php echo e(date('d/m/Y',strtotime($member->joining_date))); ?></span></label>
            <?php if(strcmp($member->status,'deleted')===0): ?>
            <label for="">Leaving Date:<span><?php echo e(date('d/m/Y',strtotime($member->leaving_date))); ?></span></label>
            <?php endif; ?>
            <label for="">Last Modified By:<span><?php echo e($member->user->name); ?></span></label>
            <label for="">Created At<span><?php echo e(date('d/m/Y h:m:i A',strtotime($member->created_at))); ?></span></label>
            <label for="">Updated At<span><?php echo e(date('d/m/Y h:m:i A',strtotime($member->updated_at))); ?></span></label>
        </div>

        <div class="payment-details">
            <h3>Last 5 payments</h3>
            <table class="table table-dark table-striped table-hover table-bordered">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Date</th>
                        <th>Amount</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="clickable" data-href="<?php echo e(route('payments.show',$p->id)); ?>">
                        <td class="center"><?php echo e($loop->iteration); ?></td>
                        <td class="center"><?php echo e(date('d/m/Y h:i:s a',strtotime($p->created_at))); ?></td>
                        <td class="right"><?php echo e(number_format($p->amount)); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot>
                    <tr>
                        <td class="center" colspan="3"><a href="<?php echo e(route('payments.index')); ?>">See all payments</a></td>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>

    <div class="member-history">
        <h3>Month details</h3>
            <table class="table table-dark table-striped table-hover table-bordered">
                <thead>
                    <tr>
                        <th rowspan="2">No.</th>
                        <th rowspan="2">Month</th>
                        <th colspan="2" class="hide-in-low-res">Payment</th>
                        <th colspan="2" class="hide-in-low-res">Adjustment</th>
                        <th rowspan="2">Rent</th>
                        <th rowspan="2">Due</th>
                    </tr>
                    <tr class="hide-in-low-res">
                        <th>Details</th>
                        <th>Total</th>
                        <th>Details</th>
                        <th>Total</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $membersMonths; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td class="left"><a href="<?php echo e(route('months.show',$mm->month->id )); ?>"><?php echo e($mm->month->name); ?></a></td>
                        <td class="td-flex hide-in-low-res">
                            <?php if(count($mm->payments->where('status','active'))==0): ?>
                            <?php echo e('-'); ?>

                            <?php else: ?>
                            <?php $__currentLoopData = $mm->payments->where('status','active'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(route('payments.show',$payment->id)); ?>" class="td-span-parent">
                                <span><?php echo e(number_format($payment->amount)); ?></span>
                                <span><?php echo e('['.date('d/m/Y',strtotime($payment->created_at)).']'); ?></span>
                            </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </td>
                        <td class="right hide-in-low-res">
                            <span><?php echo e(number_format($mm->payments->where('status','active')->sum('amount'))); ?></span>
                        </td>
                        <td class="td-flex hide-in-low-res">
                            <?php if(count($mm->adjustments->where('status','active'))==0): ?>
                            <?php echo e('-'); ?>

                            <?php else: ?>
                            <?php $__currentLoopData = $mm->adjustments->where('status','active'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $adjustment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(route('adjustments.show',$adjustment->id)); ?>" class="td-span-parent">
                                <span><?php echo e(number_format($adjustment->amount)); ?></span>
                                <span><?php echo e('['.date('d/m/Y',strtotime($adjustment->created_at)).']'); ?></span>
                            </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </td>
                        <td class="right hide-in-low-res">
                            <span><?php echo e(number_format($mm->adjustments->where('status','active')->sum('amount'))); ?></span>
                        </td>
                        <td class="right"><?php echo e(number_format($mm->rent_this_month)); ?></td>
                        <td class="right"><?php echo e(number_format($mm->due)); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
    </div>

    <div id="member_delete_div" class="member-delete-div hide">
        <form action="<?php echo e(route('members.destroy',$member)); ?>" method="POST" id="member_delete_form">
            <?php echo csrf_field(); ?>
            <?php echo method_field("DELETE"); ?>

            <legend>Delete Member</legend>

            <label for="member_delete_password" class="form-label">Enter your password</label>
            <input type="password" id="member_delete_password" placeholder="enter your password" class="form-control">
            <span id="member-delete-error" class="member-delete-password-error"></span>

            <input type="checkbox" id="member_delete_permanent" class="form-check-input">
            <label for="member_delete_permanent" class="form-label">Check if delete permanently</label>

            <div class="btn-container">
                <button type="submit" class="btn btn-primary">Confirm</button>
                <button type="button" id="member_delete_close" class="btn btn-secondary">Close</button>
            </div>
        </form>
    </div>
</div>
<?php /**PATH D:\My Codes\MessManagementV2\resources\views/member/show.blade.php ENDPATH**/ ?>