<table class="table table-dark table-striped table-hover table-bordered">
    <thead>
        <tr>
            <th>No</th>
            <th>Date</th>
            <th>Member</th>
            <th>Amount</th>
            <th>Status</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr class="clickable" data-href="<?php echo e(route('payments.show',$payment->id)); ?>">
            <td class="center"><?php echo e($loop->iteration); ?></td>
            <td class="center"><?php echo e(date('d/m/Y',strtotime($payment->created_at))); ?></td>
            <td class="center"><?php echo e($payment->memberMonth->member->name); ?></td>
            <td class="center"><?php echo e(number_format($payment->amount)); ?></td>
            <td class="center"><?php echo e(ucwords($payment->status)); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php echo e($payments->links()); ?>

<?php /**PATH D:\My Codes\MessManagementV2\resources\views/payment/search.blade.php ENDPATH**/ ?>