<table class="table table-dark table-striped table-hover table-bordered">
    <thead>
        <tr>
            <th>No</th>
            <th>Date</th>
            <th>Member</th>
            <th>Type</th>
            <th>Amount</th>
            <th>Status</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $adjustments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $adjustment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr class="clickable" data-href="<?php echo e(route('adjustments.show',$adjustment->id)); ?>">
            <td class="center"><?php echo e($loop->iteration); ?></td>
            <td class="center"><?php echo e(date('d/m/Y',strtotime($adjustment->created_at))); ?></td>
            <td class="center"><?php echo e($adjustment->memberMonth->member->name); ?></td>
            <td class="center"><?php echo e(ucwords($adjustment->type)); ?></td>
            <td class="center"><?php echo e(number_format($adjustment->amount)); ?></td>
            <td class="center"><?php echo e(ucwords($adjustment->status)); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php echo e($adjustments->links()); ?>

<?php /**PATH D:\My Codes\MessManagementV2\resources\views/adjustment/search.blade.php ENDPATH**/ ?>