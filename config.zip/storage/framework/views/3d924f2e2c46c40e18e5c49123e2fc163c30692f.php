<div id="payment_index" class="payment-index">
    <h2>Payments Index</h2>

    <div class="top top-hide">
        <span id="payment_index_filter_trigger" class="filter-show filter-close">Filter<svg xmlns="http://www.w3.org/2000/svg" height="48" width="48"><path d="M24 40 8 24 24 8l2.1 2.1-12.4 12.4H40v3H13.7l12.4 12.4Z"/></svg></span>

        <div class="form-group search">
            <label for="payment_index_search" class="form-label">Search payment</label>
            <input type="text" id="payment_index_search" class="form-control" placeholder="search by name, email, phone" autocomplete="OFF" onkeyup="searchPayment()">
        </div>

        <div class="form-group select">
            <label for="payment_index_from" class="form-label">Select from date</label>
            <input type="date" id="payment_index_from" class="form-control" placeholder="enter from date" autocomplete="OFF" onchange="searchPayment()">
        </div>

        <div class="form-group select">
            <label for="payment_index_to" class="form-label">Select to date</label>
            <input type="date" id="payment_index_to" class="form-control" placeholder="enter to date" autocomplete="OFF" onchange="searchPayment()">
        </div>

        <div class="form-group select">
            <label for="payment_index_status" class="form-label">Select a payment status</label>
            <select id="payment_index_status" class="form-select" onchange="searchPayment()">
                <option value="all">All</option>
                <option value="pending">Pending</option>
                <option value="active" selected>Active</option>
                <option value="inactive">Inactive</option>
                <option value="deleted">Deleted</option>
            </select>
        </div>

        <div class="form-group select">
            <label for="payment_index_limit" class="form-label">Select a limit</label>
            <select id="payment_index_limit" class="form-select" onchange="searchPayment()">
                <option value="5">5</option>
                <option value="10" selected>10</option>
                <option value="25">25</option>
                <option value="50">50</option>
                <option value="100">100</option>
                <option value="500">500</option>
            </select>
        </div>

        <a href="<?php echo e(route('payments.create')); ?>" id="payment_index_create" class="btn btn-success">Create</a>
    </div>

    <div id="payment_index_table_container" class="table-container">
        <table class="table table-dark table-striped table-hover table-bordered">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Date</th>
                    <th>Member</th>
                    <th>Amount</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="clickable" data-href="<?php echo e(route('payments.show',$payment->id)); ?>">
                    <td class="center"><?php echo e($loop->iteration); ?></td>
                    <td class="center"><?php echo e(date('d/m/Y',strtotime($payment->created_at))); ?></td>
                    <td class="center"><?php echo e($payment->memberMonth->member->name); ?></td>
                    <td class="center"><?php echo e(number_format($payment->amount)); ?></td>
                    <td class="center"><?php echo e(ucwords($payment->status)); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php echo e($payments->links()); ?>

    </div>
</div>
<?php /**PATH D:\My Codes\MessManagementV2\resources\views/payment/index.blade.php ENDPATH**/ ?>