<table class="table table-dark table-striped table-hover table-bordered">
    <thead>
        <tr>
            <th>No</th>
            <th>Name</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Status</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr class="clickable" data-href="<?php echo e(route('users.show',$user->id)); ?>">
            <td class="center"><?php echo e($loop->iteration); ?></td>
            <td class="left"><?php echo e($user->name); ?></td>
            <td class="center"><?php echo e($user->email); ?></td>
            <td class="center"><?php echo e($user->phone); ?></td>
            <td class="center"><?php echo e(ucwords($user->status)); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php echo e($users->links()); ?>

<?php /**PATH D:\My Codes\MessManagementV2\resources\views/user/search.blade.php ENDPATH**/ ?>