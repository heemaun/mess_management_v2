<div id="member_edit" class="member-edit">
    <h2>Member Edit</h2>
    <form action="<?php echo e(route('members.update',$member->id)); ?>" method="POST" id="member_edit_form">
        <?php echo csrf_field(); ?>
        <?php echo method_field("PUT"); ?>

        <label for="member_edit_name">Name</label>
        <input type="text" name="name" id="member_edit_name" placeholder="enter member name" autocomplete="OFF" class="form-control" value="<?php echo e($member->name); ?>">
        <span class="member-edit-error" id="member_edit_name_error"></span>

        <label for="member_edit_phone">Phone</label>
        <input type="number" name="phone" id="member_edit_phone" placeholder="enter member phone" autocomplete="OFF" class="form-control" value="<?php echo e($member->phone); ?>">
        <span class="member-edit-error" id="member_edit_phone_error"></span>

        <label for="member_edit_email">Email</label>
        <input type="text" email="email" id="member_edit_email" placeholder="enter member email" autocomplete="OFF" class="form-control" value="<?php echo e($member->email); ?>">
        <span class="member-edit-error" id="member_edit_email_error"></span>

        <label for="member_edit_initial_balance">Initial Balance</label>
        <input type="number" name="initial_balance" id="member_edit_initial_balance" placeholder="enter member initial balance" autocomplete="OFF" class="form-control" value="<?php echo e($member->initial_balance); ?>">
        <span class="member-edit-error" id="member_edit_initial_balance_error"></span>

        <label for="member_edit_current_balance">Current Balance</label>
        <input type="number" name="current_balance" id="member_edit_current_balance" placeholder="enter member current balance" autocomplete="OFF" class="form-control" value="<?php echo e($member->current_balance); ?>">
        <span class="member-edit-error" id="member_edit_current_balance_error"></span>

        <label for="member_edit_joining_date">Joining date</label>
        <input type="date" name="joining_date" id="member_edit_joining_date" placeholder="enter member joining date" autocomplete="OFF" class="form-control" value="<?php echo e($member->joining_date); ?>">
        <span class="member-edit-error" id="member_edit_joining_date_error"></span>

        <?php if(strcmp($member->status,'deleted')==0): ?>
        <label for="member_edit_leaving_date">Leaving date</label>
        <input type="date" name="leaving_date" id="member_edit_leaving_date" placeholder="enter member leaving date" autocomplete="OFF" class="form-control" value="<?php echo e($member->leaving_date); ?>">
        <span class="member-edit-error" id="member_edit_leaving_date_error"></span>
        <?php endif; ?>

        <label for="member_edit_status" class="form-label">Select a status</label>
        <select id="member_edit_status" class="form-select">
            <option value="">Select a status</option>
            <option value="active" <?php echo e((strcmp('active',$member->status)==0) ? 'selected' : ''); ?>>Active</option>
            <option value="inactive" <?php echo e((strcmp('inactive',$member->status)==0) ? 'selected' : ''); ?>>Inactive</option>
            <option value="pending" <?php echo e((strcmp('pending',$member->status)==0) ? 'selected' : ''); ?>>Pending</option>
            <?php if(strcmp('deleted',$member->status)==0): ?>
            <option value="deleted" <?php echo e((strcmp('deleted',$member->status)==0) ? 'selected' : ''); ?>>Deleted</option>
            <?php endif; ?>
        </select>
        <span id="member_edit_status_error" class="member-edit-error"></span>

        <label for="member_edit_floor" class="form-label">Select a floor</label>
        <select id="member_edit_floor" class="form-select">
            <option value="">Select a floor</option>
            <option value="Ground Floor" <?php echo e((strcmp('Ground Floor',$member->floor)==0)? 'selected' : ''); ?>>Ground Floor</option>
            <option value="1st Floor" <?php echo e((strcmp('1st Floor',$member->floor)==0)? 'selected' : ''); ?>>1st Floor</option>
            <option value="2nd Floor" <?php echo e((strcmp('2nd Floor',$member->floor)==0)? 'selected' : ''); ?>>2nd Floor</option>
        </select>
        <span id="member_edit_floor_error" class="member-edit-error"></span>

        <div class="btn-container">
            <button type="submit" class="btn btn-primary">Update</button>
            <a href="<?php echo e(route('members.show',$member->id)); ?>" id="member_edit_back" class="btn btn-secondary">Back</a>
        </div>
    </form>
</div>
<?php /**PATH D:\My Codes\MessManagementV2\resources\views/member/edit.blade.php ENDPATH**/ ?>