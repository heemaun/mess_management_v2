<div id="notice_edit" class="notice-edit">
    <h2>Notice Edit</h2>
    <form action="<?php echo e(route('notices.update',$notice->id)); ?>" method="POST" id="notice_edit_form">
        <?php echo csrf_field(); ?>
        <?php echo method_field("PUT"); ?>

        <label for="notice_edit_heading">Heading</label>
        <textarea name="heading" id="notice_edit_heading" placeholder="enter notice heading" autocomplete="OFF" class="form-control heading"><?php echo e($notice->heading); ?></textarea>
        <span class="notice-edit-error" id="notice_edit_heading_error"></span>

        <label for="notice_edit_body">Body</label>
        <textarea name="body" id="notice_edit_body" placeholder="enter notice body" autocomplete="OFF" class="form-control body"><?php echo e($notice->body); ?></textarea>
        <span class="notice-edit-error" id="notice_edit_body_error"></span>

        <label for="notice_edit_status" class="form-label">Select a status</label>
        <select id="notice_edit_status" class="form-select">
            <option value="">Select a status</option>
            <option value="active" <?php echo e((strcmp('active',$notice->status)==0) ? 'selected' : ''); ?>>Active</option>
            <option value="inactive" <?php echo e((strcmp('inactive',$notice->status)==0) ? 'selected' : ''); ?>>Inactive</option>
            <option value="pending" <?php echo e((strcmp('pending',$notice->status)==0) ? 'selected' : ''); ?>>Pending</option>
            <?php if(strcmp('deleted',$notice->status)==0): ?>
            <option value="deleted" <?php echo e((strcmp('deleted',$notice->status)==0) ? 'selected' : ''); ?>>Deleted</option>
            <?php endif; ?>
        </select>
        <span id="notice_edit_status_error" class="notice-edit-error"></span>

        <div class="btn-container">
            <button type="submit" class="btn btn-primary">Update</button>
            <a href="<?php echo e(route('notices.show',$notice->id)); ?>" id="notice_edit_back" class="btn btn-secondary">Back</a>
        </div>
    </form>
</div>
<?php /**PATH D:\My Codes\MessManagementV2\resources\views/notice/edit.blade.php ENDPATH**/ ?>